<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Spatie\Browsershot\Browsershot;
use JanDrda\LaravelGoogleCustomSearchEngine\LaravelGoogleCustomSearchEngine;


Route::get('/', function () {
    return view('welcome');
});


Route::get('img', function () {
    $base64Data = Browsershot::url('https://farmaciacatedral.com.py')
 
   
    ->base64Screenshot();
 
  
    return view('screenshot',['image'=>'data:image/jpeg;base64,'.$base64Data]);
}); 

Route::get('cse',function(){
    $fulltext = new LaravelGoogleCustomSearchEngine(); // initialize
$results = $fulltext->getResults('some phrase'); // get first 10 results for query 'some phrase' 
});
