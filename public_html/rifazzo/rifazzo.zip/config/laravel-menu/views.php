<?php

return array(
    'bootstrap-items' => 'laravel-menu::bootstrap-navbar-items',
    'leftnav-items'=>'laravel-menu::admin-leftnav-items',

);
