
 <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="section-title text-left">
                            <h5>HELP</h5>
                            <hr>
                        </div><!-- end title -->

                        <div class="menu-widget">
                            <p>Here is your content of the callout box lorem ipsum dolor sit amet, consectetuer adipiscing elit.
Aenean commodo ligula eget dolor. Aenean massa.</p>
                            <ul class="check">
                                <li><a href="#">FAQS</a></li>
                                <li><a href="#">Contact</a></li>
                                <li><a href="#">Money Back Terms</a></li>
                                <li><a href="#">Privacy</a></li>
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Forums</a></li>
                            </ul><!-- end check -->
                        </div><!-- end menu-widget -->
                    </div><!-- end col -->

                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="section-title text-left">
                            <h5>COMPANY INFO</h5>
                            <hr>
                        </div><!-- end title -->

                        <div class="menu-widget">
                            <ul class="check">
                                <li><a href="#">Our Team Members</a></li>
                                <li><a href="#">Worldwide Offices</a></li>
                                <li><a href="#">Worldwide Meet Up</a></li>
                                <li><a href="#">Awards & Reviews</a></li>
                                <li><a href="#">SEOMARKT in Press</a></li>
                                <li><a href="#">Carrers</a></li>
                                <li><a href="#">User Guide</a></li>
                                <li><a href="#">Knowledgebase</a></li>
                                <li><a href="#">Affiliate</a></li>
                            </ul><!-- end check -->
                        </div><!-- end menu-widget -->
                    </div><!-- end col -->

                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="section-title text-left">
                            <h5>GET IN TOUCH</h5>
                            <hr>
                        </div><!-- end title -->

                        <div class="contact-widget">
                            <ul class="contact">
                                <li><a href="#"><i class="fa fa-facebook"></i> seomarkt</a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i> @seomarkt</a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i> +seomarkt</a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i> seomarkt</a></li>
                                <li><a href="#"><i class="fa fa-phone"></i> +90 987 654 32 10</a></li>
                                <li><a href="#"><i class="fa fa-fax"></i> +90 987 654 32 10</a></li>
                                <li><a href="#"><i class="fa fa-envelope-o"></i> support@yoursite.com</a></li>
                                <li><a href="#"><i class="fa fa-map-marker"></i> 21 Revolution Street Paris, France</a></li>
                            </ul><!-- end check -->
                        </div><!-- end menu-widget -->
                    </div><!-- end col -->

                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="section-title text-left">
                            <h5>SUBSCRIBE FOR NEWS</h5>
                            <hr>
                        </div><!-- end title -->

                        <div class="newsletter-widget">
                            <p>Subscribe our newsletter for discount and coupon codes! 10.000+ Subscribers can not be wrong!</p>
                            <form>
                                <input type="text" class="form-control input-lg" placeholder="Your name" />
                                <input type="email" class="form-control input-lg" placeholder="Email" />
                                <button class="btn btn-primary btn-block">Subscribe Now</button>
                            </form>
                        </div><!-- end newsletter -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->  
        </footer><!-- end footer -->

        <div class="copyrights">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 text-left">
                        <a class="footer-brand" href="index-2.html"><img src="images/flogo.png" alt=""></a>
                    </div>
                    <div class="col-md-8 text-right">
                        <ul class="list-inline">
                            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li><a href="#">Terms of Usage</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Sitemap</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </div>
                </div><!-- end row -->
            </div><!-- end container -->  
        </div><!-- end copy -->
    </div><!-- end wrapper -->

<?php wp_footer(); ?>

    <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/plugins.js"></script>

</body>

</html>
