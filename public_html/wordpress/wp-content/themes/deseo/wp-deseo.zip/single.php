<?php get_header(); ?>
        <section class="section lb">
            <div class="container">
                <div class="row">
                    <div class="content col-md-9 col-sm-12">
                        <div class="blog-micro-wrapper">
                            <?php if (have_posts()): while (have_posts()) : the_post(); ?>
                            <div class="post-micro clearfix text-center">
                                <div class="post-media clearfix">
                                    <a href="single.html" title=""><img src="upload/single.png" alt="" class="img-responsive"></a>
                                </div><!-- end post-media -->
    
                                <div class="large-post-meta">
                                    <span class="avatar"><a href="author.html"><img src="upload/avatar_01.png" alt="" class="img-circle"> Jenny DOE</a></span>
                                    <small>&#124;</small>
                                    <span><a href="category.html"><i class="fa fa-clock-o"></i> 21 May 2016</a></span>
                                    <small class="hidden-xs">&#124;</small>
                                    <span class="hidden-xs"><a href="single.html#comments"><i class="fa fa-comments-o"></i> 12</a></span>
                                    <small class="hidden-xs">&#124;</small>
                                    <span class="hidden-xs"><a href="single.html"><i class="fa fa-eye"></i> 444</a></span>
                                </div><!-- end meta -->
                            
                                    <!-- post title -->
                                      <h3 class="entry-title">
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                                          </h3>
                                <div class="post-sharing clearfix">
                                    <ul class="list-inline social-small">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div><!-- end post-sharing -->
                            </div><!-- end post-micro -->

                            <div class="post-desc clearfix">
                               <?php the_content(); // Dynamic Content ?>
                                <div class="tags clearfix">
                                    <?php the_tags( __( 'Tags: ', 'wpbootstrapsass' ), ', ', '<li>'); // Separated by commas with a line break at the end ?>
                                   
                                </div><!-- end tags -->
                            </div><!--end post-desc -->
                        </div><!-- end wrapper -->
                    <?php endwhile; ?>
                <?php endif; ?>
                        <div class="blog-micro-wrapper">
                            <div class="postpager">
                                <ul class="pager row">
                                    <li class="previous col-md-6 col-sm-12 text-right">
                                        <div class="post">
                                            <div class="mini-widget-thumb">
                                                <a href="single.html">
                                                    <img alt="" src="upload/big_blog_01.png" class="img-responsive alignright img-circle">
                                                </a>
                                            </div>
                                            <div class="mini-widget-title">
                                                <a href="single.html"> Looking Logo Designer ($15 Budget) </a>
                                                <small>Previous Post</small>
                                            </div>
                                        </div>     
                                    </li>
                                    <li class="next col-md-6 col-sm-12 text-left">
                                        <div class="post">
                                            <div class="mini-widget-thumb">
                                                <a href="single.html">
                                                    <img alt="" src="upload/big_blog_02.png" class="img-responsive alignleft img-circle">
                                                </a>
                                            </div>
                                            <div class="mini-widget-title">
                                                <a href="single.html"> How to Make a Logo Urgent! </a>
                                                <small>Next Post</small>
                                            </div>
                                        </div>  
                                    </li>
                                </ul>   
                            </div><!-- end postpager -->
                        </div><!-- end post-micro -->

                        <div class="blog-micro-wrapper">
                            <div class="authorbox">
                                <div class="row">
                                    <div class="col-sm-12 col-md-12">
                                        <div class="post-padding clearfix">
                                            <div class="avatar-author">
                                                <a href="author.html">
                                                    <img alt="" src="upload/avatar_01.png" class="img-responsive img-circle">
                                                </a>
                                            </div>
                                            <div class="author-title desc">
                                                <h4><a href="single.html">Amanda ERGONY</a></h4>
                                                <a class="authorlink" href="https://showwp.com/">https://showwp.com</a>
                                                <p>She is the founder and editor of ShowWP Trending Design Sources. She also founder of WPSEOTools.com. Learn more about she here and connect with she on Twitter, Facebook, Google+.</p>
                                                <ul class="list-inline social-small">
                                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div><!-- end col -->
                                </div><!-- end row -->
                            </div><!-- end authorbox -->
                        </div><!-- end post-micro -->

                        <div class="blog-micro-wrapper">
                            <div class="related-posts">
                                <div class="section-title text-left">
                                    <h5>3 Comments</h5>
                                    <hr>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel panel-info">
                                            <div class="panel-body comments">
                                                <ul class="media-list">
                                                    <li class="media">
                                                        <div class="comment">
                                                            <a href="#" class="pull-left">
                                                                <img src="upload/avatar_01.png" alt="" class="img-circle">
                                                            </a>
                                                            <div class="media-body">
                                                                <strong class="text-success">Jane Doe</strong>
                                                                <span class="text-muted">
                                                                <small class="text-muted">6 days ago</small></span>
                                                                <p>
                                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, <a href="#">#some link </a>.
                                                                </p>
                                                                <a href="#" class="btn btn-primary btn-sm">Reply</a>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <br>
                                                        </div>
                                                        <ul class="media-list">
                                                            <li class="media">
                                                                <div class="comment">
                                                                    <a href="#" class="pull-left">
                                                                        <img src="upload/avatar_01.png" alt="" class="img-circle">
                                                                    </a>
                                                                    <div class="media-body">
                                                                        <strong class="text-success">MrAwesome</strong>
                                                                        <span class="text-muted">
                                                                        <small class="text-muted">2 days ago</small></span>
                                                                        <p>
                                                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet.
                                                                        </p>
                                                                        <a href="#" class="btn btn-primary btn-sm">Reply</a>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                            </li>
                                                            <li class="media">
                                                                <div class="comment">
                                                                    <a href="#" class="pull-left">
                                                                        <img src="upload/avatar_01.png" alt="" class="img-circle">
                                                                    </a>
                                                                    <div class="media-body">
                                                                        <strong class="text-success">Miss Lucia</strong>
                                                                        <span class="text-muted">
                                                                        <small class="text-muted">15 minutes ago</small></span>
                                                                        <p>
                                                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet.
                                                                        </p>
                                                                        <a href="#" class="btn btn-primary btn-sm">Reply</a>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="media">
                                                        <div class="comment">
                                                            <a href="#" class="pull-left">
                                                                <img src="upload/avatar_01.png" alt="" class="img-circle">
                                                            </a>
                                                            <div class="media-body">
                                                                <strong class="text-success">Jana Cova</strong>
                                                                <span class="text-muted">
                                                                <small class="text-muted">12 days ago</small></span>
                                                                <p>
                                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet.
                                                                </p>
                                                                <a href="#" class="btn btn-primary btn-sm">Reply</a>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </li>
                                                    <li class="media">
                                                        <div class="comment">
                                                            <a href="#" class="pull-left">
                                                                <img src="upload/avatar_01.png" alt="" class="img-circle">
                                                            </a>
                                                            <div class="media-body">
                                                                <strong class="text-success">Johnatan Smarty</strong>
                                                                <span class="text-muted">
                                                                <small class="text-muted">1 month ago</small></span>
                                                                <p>
                                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet.
                                                                </p>
                                                                <a href="#" class="btn btn-primary btn-sm">Reply</a>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end postpager -->
                        </div><!-- end content -->
                            <!-- comentarios -->
                        <div class="blog-micro-wrapper">
                            <div class="comment-wrap">
                                <div class="section-title text-left">
                                    <h5>Leave a Comment</h5>
                                    <hr>
                                </div>

                                <div class="contact_form">
                                    <form class="row">
                                        <div class="col-md-4 col-sm-12">
                                            <label>Name <span class="required">*</span></label>
                                            <input type="text" class="form-control" placeholder="">
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <label>Email <span class="required">*</span></label>
                                            <input type="email" class="form-control" placeholder="">
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <label>Website</label>
                                            <input type="text" class="form-control" placeholder="">
                                        </div>
                                        <div class="col-md-12 col-sm-12">
                                            <label>Comment <span class="required">*</span></label>
                                            <textarea class="form-control" placeholder=""></textarea>
                                        </div>
                                        <div class="col-md-12 col-sm-12">
                                            <input type="submit" value="Send Comment" class="btn btn-primary" />
                                        </div>
                                    </form>
                                </div><!-- end commentform -->
                            </div><!-- end postpager -->
                        </div><!-- end content -->
                        <!-- /.comentarios -->
                    </div><!-- end content -->
                    <?php get_sidebar(); ?>
                </div><!-- end row -->
            </div><!-- end container -->  
        </section>
<?php get_footer(); ?>
