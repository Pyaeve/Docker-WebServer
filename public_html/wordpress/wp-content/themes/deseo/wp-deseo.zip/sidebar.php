                    <!-- sidebar -->
                    <div class="sidebar col-md-3 col-sm-12">
                        <!-- widget -->
                        <div class="widget clearfix">
                            <?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-area-1')) ?>
                        </div><!-- / widget -->
                        <!-- widget -->
                        <div class="widget clearfix">
                            <?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-area-2')) ?>
                        </div><!-- / widget -->
                        <!-- widget -->
                        <div class="widget clearfix">
                            <?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-area-3')) ?>
                        </div><!-- / widget -->
                        <!-- widget -->
                        <div class="widget clearfix">
                            <?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-area-4')) ?>
                        </div><!-- / widget -->
                    </div>
                    <!-- /sidebar -->
                        




                      

                      
                 